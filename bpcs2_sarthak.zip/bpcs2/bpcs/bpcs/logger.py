import logging
import sys


def get_log():   
    file_handler = logging.FileHandler(filename='tmp.log', mode='w')
    handlers = [file_handler]

    logging.basicConfig(
        handlers=handlers,
        format='%(message)s',
    )
    
    log = logging.getLogger('bpcs-steg')

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    log.addHandler(ch)
    return log

log = get_log()
