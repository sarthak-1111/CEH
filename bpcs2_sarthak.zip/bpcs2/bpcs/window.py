import bpcs
from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import os

class OutLog:
    def __init__(self, edit, out=None, color=None):
        """(edit, out=None, color=None) -> can write stdout, stderr to a
        QTextEdit.
        edit = QTextEdit
        out = alternate stream ( can be the original sys.stdout )
        color = alternate color (i.e. color stderr a different color)
        """
        self.edit = edit
        self.out = None
        self.color = color

    def write(self, m):
        if self.color:
            tc = self.edit.textColor()
            self.edit.setTextColor(self.color)

        self.edit.moveCursor(QtGui.QTextCursor.End)
        self.edit.insertPlainText(m)

        if self.color:
            self.edit.setTextColor(tc)

        if self.out:
            self.out.write(m)


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("BPCS window")
        MainWindow.resize(799, 742)
        MainWindow.setStyleSheet("background-color: rgb(239, 239, 239);")

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.tab_widget = QtWidgets.QTabWidget(self.centralwidget)
        self.tab_widget.setGeometry(QtCore.QRect(360, 20, 430, 430))

        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.tab_widget.setFont(font)
        self.tab_widget.setObjectName("tab_widget")

        self.encoding_tab = QtWidgets.QWidget()
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.encoding_tab.setFont(font)
        self.encoding_tab.setObjectName("encoding_tab")

        self.path_of_image = QtWidgets.QLineEdit(self.encoding_tab)
        self.path_of_image.setGeometry(QtCore.QRect(10, 70, 320, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        font.setItalic(False)
        self.path_of_image.setFont(font)
        self.path_of_image.setAutoFillBackground(False)
        self.path_of_image.setStyleSheet("")
        self.path_of_image.setInputMask("")
        self.path_of_image.setText("")
        self.path_of_image.setDragEnabled(False)
        self.path_of_image.setObjectName("path_of_image")

        self.path_of_text = QtWidgets.QLineEdit(self.encoding_tab)
        self.path_of_text.setGeometry(QtCore.QRect(10, 180, 320, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        font.setItalic(False)
        self.path_of_text.setFont(font)
        self.path_of_text.setAutoFillBackground(False)
        self.path_of_text.setStyleSheet("")
        self.path_of_text.setInputMask("")
        self.path_of_text.setText("")
        self.path_of_text.setDragEnabled(False)
        self.path_of_text.setObjectName("path_of_text")

        self.encoding_btn = QtWidgets.QPushButton(self.encoding_tab)
        self.encoding_btn.setGeometry(QtCore.QRect(140, 320, 160, 40))
        font = QtGui.QFont()
        font.setFamily("HelveticaNeue-Light")
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.encoding_btn.setFont(font)
        self.encoding_btn.setAutoFillBackground(False)
        self.encoding_btn.setStyleSheet("QPushButton {\n"
                                        "   font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"
                                        "color : white;\n"
                                        "background-color: #4CAF50;\n"
                                        "border-radius: 2px;\n"
                                        "border: 2px solid #4CAF50;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover{\n"
                                        "    background-color: white;\n"
                                        "    color: black;\n"
                                        "}\n"
                                        "")
        self.encoding_btn.setFlat(False)
        self.encoding_btn.setObjectName("encoding_btn")

        self.img_btn = QtWidgets.QPushButton(self.encoding_tab)
        self.img_btn.setGeometry(QtCore.QRect(340, 70, 70, 30))
        font = QtGui.QFont()
        font.setFamily("HelveticaNeue-Light")
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.img_btn.setFont(font)
        self.img_btn.setAutoFillBackground(False)
        self.img_btn.setStyleSheet("QPushButton {\n"
                                   "   font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"
                                   "color : white;\n"
                                   "background-color: #4CAF50;\n"
                                   "border-radius: 2px;\n"
                                   "border: 2px solid #4CAF50;\n"
                                   "}\n"
                                   "\n"
                                   "QPushButton:hover{\n"
                                   "    background-color: white;\n"
                                   "    color: black;\n"
                                   "}\n"
                                   "")
        self.img_btn.setFlat(False)
        self.img_btn.setObjectName("img_btn")

        self.text_btn = QtWidgets.QPushButton(self.encoding_tab)
        self.text_btn.setGeometry(QtCore.QRect(340, 180, 70, 30))
        font = QtGui.QFont()
        font.setFamily("HelveticaNeue-Light")
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.text_btn.setFont(font)
        self.text_btn.setAutoFillBackground(False)
        self.text_btn.setStyleSheet("QPushButton {\n"
                                    "   font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"
                                    "color : white;\n"
                                    "background-color: #4CAF50;\n"
                                    "border-radius: 2px;\n"
                                    "border: 2px solid #4CAF50;\n"
                                    "}\n"
                                    "\n"
                                    "QPushButton:hover{\n"
                                    "    background-color: white;\n"
                                    "    color: black;\n"
                                    "}\n"
                                    "")
        self.text_btn.setFlat(False)
        self.text_btn.setObjectName("text_btn")

        self.img_label = QtWidgets.QLabel(self.encoding_tab)
        self.img_label.setGeometry(QtCore.QRect(10, 20, 161, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.img_label.setFont(font)
        self.img_label.setStyleSheet("QLabel {\n"
                                     "    background-color: rgb(232, 232, 232);\n"
                                     "}")
        self.img_label.setObjectName("img_label")

        self.text_label = QtWidgets.QLabel(self.encoding_tab)
        self.text_label.setGeometry(QtCore.QRect(10, 130, 161, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.text_label.setFont(font)
        self.text_label.setStyleSheet("QLabel {\n"
                                      "    background-color: rgb(232, 232, 232);\n"
                                      "}")
        self.text_label.setObjectName("text_label")

        self.alpha_label = QtWidgets.QLabel(self.encoding_tab)
        self.alpha_label.setGeometry(QtCore.QRect(10, 240, 161, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.alpha_label.setFont(font)
        self.alpha_label.setStyleSheet("QLabel {\n"
                                       "    background-color: rgb(232, 232, 232);\n"
                                       "}")
        self.alpha_label.setObjectName("alpha_label")

        self.alpha_txt = QtWidgets.QLineEdit(self.encoding_tab)
        self.alpha_txt.setGeometry(QtCore.QRect(190, 240, 180, 30))

        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        font.setItalic(False)
        self.alpha_txt.setFont(font)
        self.alpha_txt.setAutoFillBackground(False)
        self.alpha_txt.setStyleSheet("")
        self.alpha_txt.setInputMask("")
        self.alpha_txt.setText("")
        self.alpha_txt.setDragEnabled(False)
        self.alpha_txt.setObjectName("alpha_txt")
        self.tab_widget.addTab(self.encoding_tab, "")

        self.decoding_tab = QtWidgets.QWidget()
        self.decoding_tab.setObjectName("decoding_tab")

        self.path_of_image_2 = QtWidgets.QLineEdit(self.decoding_tab)
        self.path_of_image_2.setGeometry(QtCore.QRect(10, 70, 320, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        font.setItalic(False)
        self.path_of_image_2.setFont(font)
        self.path_of_image_2.setAutoFillBackground(False)
        self.path_of_image_2.setStyleSheet("")
        self.path_of_image_2.setInputMask("")
        self.path_of_image_2.setText("")
        self.path_of_image_2.setDragEnabled(False)
        self.path_of_image_2.setObjectName("path_of_image_2")

        self.img_btn_2 = QtWidgets.QPushButton(self.decoding_tab)
        self.img_btn_2.setGeometry(QtCore.QRect(340, 70, 70, 30))
        font = QtGui.QFont()
        font.setFamily("HelveticaNeue-Light")
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.img_btn_2.setFont(font)
        self.img_btn_2.setAutoFillBackground(False)
        self.img_btn_2.setStyleSheet("QPushButton {\n"
                                     "   font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"
                                     "color : white;\n"
                                     "background-color: #4CAF50;\n"
                                     "border-radius: 2px;\n"
                                     "border: 2px solid #4CAF50;\n"
                                     "}\n"
                                     "\n"
                                     "QPushButton:hover{\n"
                                     "    background-color: white;\n"
                                     "    color: black;\n"
                                     "}\n"
                                     "")
        self.img_btn_2.setFlat(False)
        self.img_btn_2.setObjectName("img_btn_2")

        self.decoding_btn = QtWidgets.QPushButton(self.decoding_tab)
        self.decoding_btn.setGeometry(QtCore.QRect(140, 240, 160, 40))
        font = QtGui.QFont()
        font.setFamily("HelveticaNeue-Light")
        font.setPointSize(10)
        font.setBold(True)
        font.setUnderline(False)
        font.setWeight(75)
        font.setStrikeOut(False)
        self.decoding_btn.setFont(font)
        self.decoding_btn.setAutoFillBackground(False)
        self.decoding_btn.setStyleSheet("QPushButton {\n"
                                        "   font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"
                                        "color : white;\n"
                                        "background-color: #4CAF50;\n"
                                        "border-radius: 2px;\n"
                                        "border: 2px solid #4CAF50;\n"
                                        "}\n"
                                        "\n"
                                        "QPushButton:hover{\n"
                                        "    background-color: white;\n"
                                        "    color: black;\n"
                                        "}\n"
                                        "")
        self.decoding_btn.setFlat(False)
        self.decoding_btn.setObjectName("decoding_btn")

        self.img_label_2 = QtWidgets.QLabel(self.decoding_tab)
        self.img_label_2.setGeometry(QtCore.QRect(10, 20, 161, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.img_label_2.setFont(font)
        self.img_label_2.setStyleSheet("QLabel {\n"
                                       "    background-color: rgb(232, 232, 232);\n"
                                       "}")
        self.img_label_2.setObjectName("img_label_2")

        self.alpha_txt_2 = QtWidgets.QLineEdit(self.decoding_tab)
        self.alpha_txt_2.setGeometry(QtCore.QRect(190, 140, 180, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        font.setItalic(False)
        self.alpha_txt_2.setFont(font)
        self.alpha_txt_2.setAutoFillBackground(False)
        self.alpha_txt_2.setStyleSheet("")
        self.alpha_txt_2.setInputMask("")
        self.alpha_txt_2.setText("")
        self.alpha_txt_2.setDragEnabled(False)
        self.alpha_txt_2.setObjectName("alpa_txt_2")

        self.alpha_label_2 = QtWidgets.QLabel(self.decoding_tab)
        self.alpha_label_2.setGeometry(QtCore.QRect(10, 140, 161, 30))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.alpha_label_2.setFont(font)
        self.alpha_label_2.setStyleSheet("QLabel {\n"
                                         "    background-color: rgb(232, 232, 232);\n"
                                         "}")
        self.alpha_label_2.setObjectName("alpha_label_2")
        self.tab_widget.addTab(self.decoding_tab, "")

        self.selected_img = QtWidgets.QLabel(self.centralwidget)
        self.selected_img.setGeometry(QtCore.QRect(10, 140, 320, 250))
        self.selected_img.setStyleSheet("QLabel {\n"
                                        "    border: 2px solid #4682B4;\n"
                                        "}")
        self.selected_img.setText("")
        self.selected_img.setScaledContents(True)
        self.selected_img.setObjectName("selected_img")
        
        self.selected_text = QtWidgets.QLabel(self.centralwidget)
        self.selected_text.setGeometry(QtCore.QRect(20, 90, 161, 41))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(10)
        self.selected_text.setFont(font)
        self.selected_text.setStyleSheet("QLabel {\n"
                                         "    background-color: rgb(232, 232, 232);\n"
                                         "}")
        self.selected_text.setObjectName("selected_text")

        self.output_log = QtWidgets.QTextEdit(self.centralwidget)
        self.output_log.setGeometry(QtCore.QRect(40, 470, 741, 251))
        self.output_log.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.output_log.setReadOnly(True)
        self.output_log.setObjectName("output_log")
        MainWindow.setCentralWidget(self.centralwidget)

        sys.stdout = OutLog( self.output_log, sys.stdout)
        sys.stderr = OutLog( self.output_log, sys.stderr, QtGui.QColor(255,0,0) )


        # button functions
        self.img_btn.clicked.connect(lambda: self.get_img_path(0))
        self.img_btn_2.clicked.connect(lambda: self.get_img_path(1))

        self.text_btn.clicked.connect(self.get_text_path)

        self.encoding_btn.clicked.connect(self.encoder)

        self.decoding_btn.clicked.connect(self.decoder)
        ############

        self.img_path = None
        self.text_path = None

        self.selected_text.close()
        self.selected_img.close()

        self.retranslateUi(MainWindow)
        self.tab_widget.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.path_of_image.setPlaceholderText(
            _translate("MainWindow", "Path of image"))
        self.path_of_text.setPlaceholderText(
            _translate("MainWindow", "Path of text file"))
        self.encoding_btn.setText(_translate("MainWindow", "Begin Encoding"))
        self.img_btn.setText(_translate("MainWindow", "Select"))
        self.text_btn.setText(_translate("MainWindow", "Select"))
        self.img_label.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Path of image : </p></body></html>"))
        self.text_label.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Path of text file</p></body></html>"))
        self.alpha_label.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Value of alpha : <br/></p></body></html>"))
        self.alpha_txt.setPlaceholderText(
            _translate("MainWindow", "Value of alpha"))
        self.tab_widget.setTabText(self.tab_widget.indexOf(
            self.encoding_tab), _translate("MainWindow", "Encoding"))
        self.path_of_image_2.setPlaceholderText(
            _translate("MainWindow", "Path of image"))
        self.img_btn_2.setText(_translate("MainWindow", "Select"))
        self.decoding_btn.setText(_translate("MainWindow", "Begin Decoding"))
        self.img_label_2.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Path of image : </p></body></html>"))
        self.alpha_txt_2.setPlaceholderText(
            _translate("MainWindow", "Value of alpha"))
        self.alpha_label_2.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Value of alpha : <br/></p></body></html>"))
        self.tab_widget.setTabText(self.tab_widget.indexOf(
            self.decoding_tab), _translate("MainWindow", "Decoding"))
        self.selected_text.setText(_translate(
            "MainWindow", "<html><head/><body><p align=\"center\">Selected Image</p></body></html>"))

    def get_img_path(self, val):

        self.img_path = QtWidgets.QFileDialog().getOpenFileName(None,
                        "Open Image", "./examples", "Image Files (*.png *.jpg *.bmp)")[0]

        pixmap = QtGui.QPixmap(self.img_path)
        self.selected_img.setPixmap(pixmap)

        self.selected_img.show()
        self.selected_text.show()

        if val == 0:
            self.path_of_image.setText(self.img_path)
        else:
            self.path_of_image_2.setText(self.img_path)

        print("Selected image :", self.img_path)

    def get_text_path(self):
        dialog = QtWidgets.QFileDialog()
        self.text_path = dialog.getOpenFileName(None,
                                                "Open Text file", "./examples", "Text File (*.txt)")[0]

        self.path_of_text.setText(self.text_path)

        print("Selected text :", self.text_path)

    def encoder(self):
        alpha_val = self.alpha_txt.text()
        
        if alpha_val == "":
            sys.stderr.write('Alpha value is not entered.\n')
            return

        try:
            alpha_val = float(alpha_val)

        except Exception as e:
            sys.stderr.write('Given alpha value is not a floating point value.\n')
            return

        if self.path_of_text.text() is None or \
                os.path.isfile(self.path_of_text.text()) == 0:

            sys.stderr.write('Please select a valid text file.\n')
            return

        if self.path_of_image.text() is None or \
                os.path.isfile(self.path_of_image.text() ) == 0:

            sys.stderr.write('Please select a valid image file.\n')
            return

        self.output_log.clear()

        img_name = os.path.basename(self.path_of_image.text())
        img_name = os.path.splitext(img_name)[0]

        print("\nGiven alpha value =", alpha_val)
        print("\nGiven text file =", self.path_of_text.text())
        print("\nGiven image file =",self.path_of_image.text())


        bpcs.capacity(self.path_of_image.text(),
                     alpha_val) # check max size of message you can embed in vslfile

        print("\nCapacity of the image :: \n")
        print("\n\n")

        with open('tmp.log', 'r') as fp:
            lines  = fp.readlines()
            for line in lines:
                print(line)
            

        print("\n----------------------------------\nEncoding of the image :: \n")
        print("\n\n")

        encoded_file = f"examples/{img_name}_encoded.png"

        bpcs.encode(self.path_of_image.text(),
                self.path_of_text.text(),
                encoded_file,
                alpha_val) # embed msgfile in vslfile, write to encfile

        with open('tmp.log', 'r') as fp:
            lines  = fp.readlines()
            for line in lines:
                print(line)


    def decoder(self):
        alpha_val = self.alpha_txt_2.text()
        
        if alpha_val == "":
            sys.stderr.write('Alpha value is not entered.\n')
            return

        try:
            alpha_val = float(alpha_val)

        except Exception as e:
            sys.stderr.write('Given alpha value is not a floating point value.\n')
            return


        if self.path_of_image_2.text() is None or \
            os.path.isfile(self.path_of_image_2.text() ) == 0:

            sys.stderr.write('Please select a valid image file.\n')
            return

        self.output_log.clear()

        img_name = os.path.basename(self.path_of_image_2.text())
        img_name = os.path.splitext(img_name)[0]

        print("\nGiven alpha value =", alpha_val)
        print("\nGiven image file =",self.path_of_image_2.text())

            

        decoded_file = f"examples/{img_name}_dec.txt"

        print("\n----------------------------------\Decoding of the image :: \n\n")

        bpcs.decode(self.path_of_image_2.text(), decoded_file, alpha_val) # recover message from encfile


        with open('tmp.log', 'r') as fp:
            lines  = fp.readlines()
            for line in lines:
                print(line)
